This release includes the igb FreeBSD Base Driver for Intel(R) Ethernet Network
Connections.

The igb driver supports devices based on the following controllers:
  * All 82575 and 82576-based gigabit network connections

NOTE: You can download Ethernet drivers at:
https://downloadcenter.intel.com

igb-x.x.x.tar.gz
